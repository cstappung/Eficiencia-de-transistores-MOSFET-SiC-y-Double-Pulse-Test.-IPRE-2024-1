#include <device.h>
#include <driverlib.h>


void main(void)
{
	Device_init();
	Device_initGPIO();

	GPIO_setPadConfig(DEVICE_GPIO_PIN_LED1, GPIO_PIN_TYPE_STD);
	GPIO_setDirectionMode(DEVICE_GPIO_PIN_LED1, GPIO_DIR_MODE_OUT);

    // Config Gate 3 Senal Invertida con GPIO
	GPIO_setPadConfig(2, GPIO_PIN_TYPE_STD);
	GPIO_setDirectionMode(2, GPIO_DIR_MODE_OUT);

	// Config Gate 2 y 4
	GPIO_setPadConfig(3, GPIO_PIN_TYPE_STD);
	GPIO_setDirectionMode(3, GPIO_DIR_MODE_OUT);

	// Config Enable
	GPIO_setPadConfig(0, GPIO_PIN_TYPE_STD);
	GPIO_setDirectionMode(0, GPIO_DIR_MODE_OUT);

	Interrupt_initModule();
	Interrupt_initVectorTable();

	EINT;
	ERTM;

	// Config Pierna izquierda inicio
	GPIO_writePin(2, 1);

	// Config pierna derecha
	GPIO_writePin(3, 1);

	// Config Enable
	GPIO_writePin(0, 1);

	for(;;)
	{
	    DELAY_US(500000);

	    // Config Enable
	    GPIO_writePin(0, 0);

	    DELAY_US(1000);

	    //Comenzamos T1
	    GPIO_writePin(2, 0);

	    //Esperamos exactamente T1. (Para calcular que valor poner a delay usar la siguiente formula)
	    // Delay = (T1-0.55)/2 todo en microsegundos
	    DELAY_US(13.225);

	    //Comenzamos T2
	    GPIO_writePin(2, 1);

	    // Delay = (T2-0.55)/2 todo en microsegundos
	    DELAY_US(2.225);

	    //Comenzamos T3
	    GPIO_writePin(2, 0);

	    // Delay = (T3-0.55)/2 todo en microsegundos
	    DELAY_US(2.225);

	    // Esperamos a la siguiente prueba
	    GPIO_writePin(2, 1);

	    DELAY_US(1000);

	    GPIO_writePin(0, 1);
	    DELAY_US(1000000);
	}
}
